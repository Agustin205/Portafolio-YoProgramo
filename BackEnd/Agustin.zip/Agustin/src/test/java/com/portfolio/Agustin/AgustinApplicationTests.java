package com.portfolio.Agustin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgustinApplicationTests {

	@Test
	void contextLoads() {
	}

}
